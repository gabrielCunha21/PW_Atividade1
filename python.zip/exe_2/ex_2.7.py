numero = float(input("Digite um número: "))
string = str(numero)

if string.endswith('.0') or '.' not in string:
    print("inteiro")
else:
    print("Não inteiro")
letra = input("Digite uma letra: ")

vogais ="aeiou"

if len(letra) == 1:

    if letra in "aeiou":
        print("Vogal")
    else:
        print("consoante")

else:
    print("INVALIDO")
salario = float(input("Digite o salario: "))

if salario > 10000:
    print("bom salario")
else:
    print("Faz o L")
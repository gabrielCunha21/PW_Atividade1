palavra = "ovo"
palavra_invertida = palavra[::-1]

if palavra == palavra_invertida:

    print("Palíndromo")
else:
    print("Não Palíndromo")
num = int(input("Digite um numero "))

if num < 0:
    print("Negativo")
elif num == 0:
    print("Zero")
else:
    print("Positivo")


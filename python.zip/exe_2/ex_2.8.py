numero = float(input("Digite um número: "))
string = str(numero)

if string.endswith('.0'):
    print("real")
else:
    print("Não real")
idade = int(input("Digite a sua idade: "))

if idade < 30:

    print("Você é jovem")

elif idade >=30 and idade <=60:
    
    print("Você é adulto")

else:

    print("Você é idoso")
    
idade = int(input("Digite a idade: "))
sexo = input("Digite o sexo: ")

if (idade >= 60 and sexo == 'F') or (idade >= 65 and sexo == 'M'):

    print("Você está aprovado para aposentadoria!")

else:

    print("Você não está aprovado para aposentadoria!")
temperatura = float(input("Digite a temperatura: "))

if temperatura > 37:
    print("acima do normal!")
elif temperatura < 36:
    print("abaixo do normal!")
else:
    print("normal")
genero = input("Digite o seu gênero: ")

if genero == "M":

    print("Genero masculino")

else:

    print("Genero feminino")
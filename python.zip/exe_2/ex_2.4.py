ano = int(input("Digite um ano: "))

if (ano % 4 and ano % 100 != 0) or (ano % 400 == 0):
    print("esse ano e bissextos")
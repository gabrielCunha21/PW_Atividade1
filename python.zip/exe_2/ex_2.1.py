num = 66

if num % 2 == 0:
    print("PAR")
else:
    print("IMPAR")
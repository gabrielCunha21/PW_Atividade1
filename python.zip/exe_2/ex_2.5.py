idade = int(input("Digite sua idade: "))

if idade < 18:
    print("menor de idade")

else:
    print("maior de idade")
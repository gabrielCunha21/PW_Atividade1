numero1 = int(input("Digite um numero: "))
numero2 = int(input("Digite outro numero: "))

if numero1 % numero2 == 0:
    print("Divisivel")
else:
    print("Não divisivel")
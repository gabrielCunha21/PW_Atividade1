idade = int(input("Digite a idade: "))
nacionalidade = input("Digite a nacionalidade: ")

if idade >= 18 and (nacionalidade == 'brasil' or 'Brasil'): 
    print("Você pode votar!")
else:
    print("Você não pode votar!")
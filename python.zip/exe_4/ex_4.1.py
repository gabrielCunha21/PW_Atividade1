num1 = float(input("Digite o numero: "))
num2 = float(input("Digite o numero: "))

potencia = num1**num2

print(potencia)
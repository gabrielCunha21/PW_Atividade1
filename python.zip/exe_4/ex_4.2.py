num = float(input("Digite o numero: "))

raiz = num **(1/2)

print(raiz)
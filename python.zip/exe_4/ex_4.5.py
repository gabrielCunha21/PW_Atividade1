import math

numero = int(input("Digite um numero: "))
fatorial = math.factorial(numero)

print(f"O fatorial de {numero} é {fatorial}")

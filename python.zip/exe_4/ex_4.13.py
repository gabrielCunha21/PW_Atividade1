frase = input("Digite uma frase: ")

palavras = frase.split()
palavras_semEspaco = [palavra.strip() for palavra in palavras]
frase_comEspaco = " ".join(palavras_semEspaco)

print(frase_comEspaco)
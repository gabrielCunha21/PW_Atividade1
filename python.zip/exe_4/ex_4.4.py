import math

num = float(input("Digite o numero: "))

log = math.log(num)

print(log)
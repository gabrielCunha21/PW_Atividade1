import math

angulo = int(input("digite um angulo: "))

angulo_rad = math.radians(angulo)

cos = math.cos(angulo_rad)
sen = math.sin(angulo_rad)
tan = math.tan(angulo_rad)

print(f"Coseno: {cos}\nSeno: {sen}\nTangente: {tan}")
import math

numero1 = complex(input("Digite um numero: "  ))
numero2 = complex(input("Digite um numero: "  ))

soma = (numero1) + (numero2)
produto = (numero1) * (numero2)

print(f"A soma dos numeros é {soma}, e o produto é {produto}")
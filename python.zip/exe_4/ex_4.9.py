texto= input("Digite uma frase: ")
presente= input("Digite uma palavra existente na frase: ")
inexistente= input("Digite uma palavra inexistente na frase: ")

novo_texto = texto.replace(presente, inexistente)
print(novo_texto)
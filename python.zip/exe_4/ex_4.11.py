frase = input("Digite uma frase: ")

frases = [frase[x:x + 6] for x in range(0, len(frase), 6)]

for frase in frases:

    print(frase)
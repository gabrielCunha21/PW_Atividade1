numero = int(input("Digite um número inteiro: "))
seq_fibri = [1, 1]

for i in range(2, numero):

    fibiri = seq_fibri[i - 1] + seq_fibri[i - 2]
    seq_fibri.append(fibiri)

print(f"Sequência de Fibonacci até o {numero}-ésimo termo:")
print(seq_fibri)
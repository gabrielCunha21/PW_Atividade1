soma = 0

for i in range(1, 101, 2):

    soma += i
    
print(soma)
for i in range(1,101,2):
    print(i)
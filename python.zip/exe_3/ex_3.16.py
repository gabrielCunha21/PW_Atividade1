numeros = []

maior = 0
menor = 0
for i in range (10):
    numero = float(input("Digite um número: "))
    numeros.append(numero)

maior_numero = max(numeros)
menor_numero = min(numeros)

print(f"maior: {maior_numero}")
print(f"menor: {menor_numero}")
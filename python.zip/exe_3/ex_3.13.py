num = int(input("Digite um número: "))

for i in range(1, 11):

    valor = num * i

    print(valor)
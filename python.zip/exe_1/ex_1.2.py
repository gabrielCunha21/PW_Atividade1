#Declarando Variaveis

numero_1 = 23
numero_2 = 12

soma = numero_1 + numero_2 #soma do numero 1 e 2

subtracao = numero_1 - numero_2 #ssubrtração do numero 1 e 2

divisao = numero_1 / numero_2 #divisão do numero 1 e 2

multiplicacao = numero_1 * numero_2 #multiplicação do numero 1 e 2

print(f"soma: {soma}\nsubtração: {subtracao}\ndivisão: {round(divisao,2)}\nmultiplicação {multiplicacao}")
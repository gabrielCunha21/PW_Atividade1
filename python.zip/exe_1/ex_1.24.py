import math

raio = float(input("Digite o valor do raio: "))

perimetro = 2 * math.pi * raio

print(perimetro)
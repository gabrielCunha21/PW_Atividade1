lista = ["Pato", "Rato", "Carro", "Gilmar", "Tereza"]

print(lista)
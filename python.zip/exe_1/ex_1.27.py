nome = input("Digite o seu nome: ")
salario = float(input("Digite o seu salário: "))
imposto = float(input("Digite o valor do imposto: "))

salario_final = salario - imposto
print(salario_final)
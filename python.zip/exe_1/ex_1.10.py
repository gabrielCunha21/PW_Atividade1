import math

num1 = float(input("Digite um numero: "))
num2 = float(input("Digite um numero: "))

pot = math.pow(num1,num2)

print(f"Potencia {pot}")
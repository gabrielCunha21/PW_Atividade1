import math

radianos = float(input("Digite o valor da medida de um ângulo em radianos: "))

graus = math.degrees(radianos)

print(graus)
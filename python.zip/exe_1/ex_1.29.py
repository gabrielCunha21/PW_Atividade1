nome = {"aluno1": "Carlos", "aluno2": "Ana", "aluno3": "Ricardo", "aluno4": "Larissa", "aluno5": "Felipe"}
olho = {"olho1": "azul", "olho2": "castanho", "olho3": "verde", "olho4": "azul", "olho5": "muitas cores"}
idade = {"idade1": 25, "idade2": 30, "idade3": 22, "idade4": 28, "idade5": 35}

print(nome)
print(olho)
print(idade)

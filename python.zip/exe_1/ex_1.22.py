distancia_percorrida = float(input("Digite a distância: "))
tempo_gasto = float(input("Digite o tempo: "))

velocidade_media = distancia_percorrida / tempo_gasto

print(velocidade_media)
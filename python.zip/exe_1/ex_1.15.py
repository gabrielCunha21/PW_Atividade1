import math

distancia = float(input("Digite a distância: "))
velocidade_inicial = float(input("Digite a velocidade inicial: "))

tempo = math.sqrt((2 * distancia) / 10)

print(f"O tempo que leva para atingir o solo é {tempo:.2f}.")

import math

vaA = float(input("Digite o numero [A] : "))
vaB = float(input("Digite o numero [B] : "))
vaC = float(input("Digite o numero [C] : "))

delta = (vaB**2) - (vaA*vaC*4)

formula1 = (-vaB + (delta**0.5))/(2*vaA)
formula2 = (-vaB - (delta**0.5))/(2*vaA)

print(delta)

print(f"Raiz': {formula1}\nRaiz'': {formula2}")
'''
nome, 
preço de custo,
preço de venda
quantidade

mostre o lucro que esse estoque pode gerar se todos os
produtos forem vendidos.'''

nome_Produto = input("Digite o nome do produto: ")
preço_custo = float(input("Digite o valor de custo: "))
preço_venda = float(input("Digite o valor de venda: "))
quantidade = int(input("Digite a quantidade: "))

venda = preço_venda - preço_custo

venda_total = venda * quantidade

print(f"O produto {nome_Produto} tera um lucro de R$ {venda_total:.2f}")
import math

raio = float(input("Digite o valor do raio: "))

volume = 4/3 * math.pi * raio**3

print(volume)
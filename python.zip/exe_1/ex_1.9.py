import math

Angulo = int(input("Digite aqui um angulo: "))

Angulo_rad = math.radians(Angulo)

sen = math.sin(Angulo_rad)
cos = math.cos(Angulo_rad)
tan = math.tan(Angulo_rad)

print (f"Seno: {sen:.2f} \nCoseno: {cos:.2f} \nTangente: {tan:.2f}")
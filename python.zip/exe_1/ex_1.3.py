#buscando dados ao usuario

num_1 = float(input("NUMERO 1: "))
num_2 = float(input("NUMERO 2: "))
num_3 = float(input("NUMERO 3: "))

media = (num_1 + num_2 + num_3)/3 # calculando a media

print("A sua media: ", round(media, 2)) #imprimindo
vel_ini = float(input("Digite a velocidade inicial: "))
vel_final = float(input("Digite a velocidade fina l:"))
transmicao = float(input("Digite o tempo de transição entre as velocidades: "))

vel_ini_ms = vel_ini * 1000 / 3600
vel_ms = vel_final * 1000 / 3600
aceleracao = (vel_ms - vel_ini_ms) / transmicao
print(round(aceleracao,2))
lado1 = float(input("Digite o valor: "))
lado2 = float(input("Digite o valor: "))

hipotenusa = (lado1**2 + lado2**2)**0.5
print(f"O valor da hipotenusa é: {hipotenusa}")
base = float(input("Digite a base: "))
altura = float(input("Digite a altura: "))

area = base*altura/2

print (f"Area: {area}")
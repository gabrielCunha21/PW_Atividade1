num = float(input("digite um numero: "))

num = num*2

print(f"dobro: {num:.2f}")
import math

num = float(input("digite um numero: "))

num = math.sqrt(num)

print(f"dobro: {num:.2f}")
#Declarando Variaveis

nome = "Gabriel" 
idade = str(18)

#Imprimindo valores

print("nome: {}\nidade: {} Anos.".format(nome,idade))
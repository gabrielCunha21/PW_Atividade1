conjunto1 = {2, 4, 9, 8, 5, 3, 5}
conjunto2 = {9, 8, 7, 8, 5, 4, 0}

print(conjunto1 | conjunto2)
 
print(conjunto1 & conjunto2)

print(conjunto1 - conjunto2)
#buscando dados ao usuario

altura_m = float(input("Digite sua altura: "))
peso_kq = float(input("Digite seu peso: "))

imc = peso_kq/(altura_m*altura_m) # calculando imc por peso/altura^2

print("Seu IMC: ", round(imc, 3)) #imprimindo resultado
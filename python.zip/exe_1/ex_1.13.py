altura = float(input("Digite a altura: "))
largura = float(input("Digite a largura: "))

perimetro = 2*altura + 2*largura
area = altura*largura

print (f"Perimetro: {perimetro}\nArea: {area}")
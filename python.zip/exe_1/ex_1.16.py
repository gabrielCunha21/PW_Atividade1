var_ini = float(input("Digite o valor inicial do investimento: "))
juros = float(input("Digite a taxa de juros: "))
tempo = int(input("Digite o número de anos: "))

cal_juros = var_ini * (1 + juros)**tempo

print(f"Valor final de R${cal_juros}")
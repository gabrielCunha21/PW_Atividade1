cateto1 = float(input("Digite o comprimento do cateto: "))
cateto2 = float(input("Digite o comprimento do cateto: "))

area = 0.5 * cateto1 * cateto2
print(area)
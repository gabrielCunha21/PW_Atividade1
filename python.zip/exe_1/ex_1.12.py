import math

raio = int(input("Digite o raio de um circulo: "))

area = math.pi*raio**2
perimetro = 2*math.pi*raio

print (f"Area: {area:.2f}\nPerimetro: {perimetro:.2f}")
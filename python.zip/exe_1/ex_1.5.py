soma = 0 #declarando variavel para usala no FOR

#recebendo dados e somando

for i in range(3):
    i = float(input("Digite um numero: "))

    soma = i + soma

print(f"Soma: {soma:.2f}") #imprimindo resultado
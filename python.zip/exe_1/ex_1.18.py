massa = float(input("Digite a massa do objeto (Kg): "))
aceleracao = float(input("Digite a aceleração do objeto (m/s²): "))

formula = massa * aceleracao
print(formula)